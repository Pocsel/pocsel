/*
** list.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Fri Nov 20 20:53:45 2009 martin tapia
** Last update Sat Nov 21 12:09:45 2009 martin tapia
*/

#include <stdlib.h>
#include "mytar.h"

int		list_size(t_list *list)
{
  int		size;

  size = 0;
  while (list != NULL)
    {
      size = size + 1;
      list = list->next;
    }
  return (size);
}

void		list_add(t_list **list, t_header header, void *data, int size)
{
  t_list	*new;
  t_list	*cur;

  new = malloc(sizeof(*new));
  new->header = header;
  new->data = data;
  new->size = size;
  new->next = NULL;
  if (*list == NULL)
    *list = new;
  else
    {
      cur = *list;
      while (cur->next != NULL)
	cur = cur->next;
      cur->next = new;
    }
}

void		list_free(t_list **list)
{
  t_list	*cur;
  t_list	*tmp;

  if (*list == NULL)
    return ;
  cur = *list;
  while (cur != NULL)
    {
      free(cur->data);
      cur = cur->next;
    }
  cur = *list;
  while (cur != NULL)
    {
      tmp = cur->next;
      free(cur);
      cur = tmp;
    }
  *list = NULL;
}
