/*
** mytar.h for mytar in /u/all/tapia_a/cu/rendu/rush/mytar
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Fri Nov 20 20:41:58 2009 martin tapia
** Last update Sun Nov 22 15:32:42 2009 martin tapia
*/

#ifndef __MY_TAR_H__
#define __MY_TAR_H__

#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

#define GZIP_CHUNK 16384
#define DECIMAL "0123456789"
#define OCTAL "01234567"
#define RECORDSIZE 512

typedef struct	s_options
{
  char		create;
  char		extract;
  char		file;
  char		list;
  char		perm;
  char		verbose;
  char		gzip;
}		t_options;

typedef struct	s_header
{
  char		name[100];
  char		mode[8];
  char		owner[8];
  char		group[8];
  char		size[12];
  char		time[12];
  char		checksum[8];
  char		flag[1];
  char		link[100];
  char		padding[255];
}		t_header;

/*
** string.c
*/
int		my_strcmp(char *s1, char *s2);
char		*my_strcpy(char *dest, char *src);
int		my_strlen(char *str);
void		my_putchar(char c);
int		my_putstr(char *str);

/*
** my_getnbr_base.c
*/
int		my_getnbr_base(char *str, char *base);

/*
** utils.c
*/
int		header_is_empty(t_header *header);
char		*malloc_header_field(char *tab, int size);
void		die_with_error(char *);
char		*my_strcat(char *str1, char *str2);
int		file_is_link(char *path);

/*
** revstr.c
*/
char		*my_revstr(char *str);

/*
** convert_base.c
*/
char		*convert_base(int i, char *base_from, char *base_to);

/*
** to_octal.c
*/
void		to_octal(char *tab, int size, int val, int null_finish);

/*
** list.c
*/
typedef struct	s_list
{
  t_header	header;
  char		*data;
  int		size;
  struct s_list	*next;
}		t_list;
int		list_size(t_list *list);
void		list_add(t_list **list, t_header header, void *data, int size);
void		list_free(t_list **list);

/*
** header.c
*/
void		write_header_name(char *tab, char *file);
void		write_header_flag(char *tab, mode_t st_mode);
void		write_header_link(char *tab, struct stat s, char *file);
void		write_header_padding(char *tab);
void		write_header_checksum(t_header *header);

/*
** main.c
*/
void		unarchive(int fd, t_options *options);
void		file_add(char *file, t_list **archive, t_options *options);

/*
** dir.c
*/
void		dir_add(DIR *d, t_list **archive, char *path, t_options *o);

/*
** fill_archive.c
*/
t_header	fill_header(char *file);
void		fill_archive(int argc, char **argv, t_list **archive, t_options *o);

/*
** unarchive.c
*/
int		get_header_filesize(t_header *header);
void		unarchive_write(int fd, t_header *header, t_options *options);

/*
** verify_checksum.c
*/
int		verify_checksum(t_header *header);

/*
** options.c
*/
void		options_default(t_options *options);
int		options_set(t_options *options, char o);
void		options_parse(t_options *options, char *str);

/*
** option_t.c
*/
int		listing(t_options *options, char *path, t_header *header, int fd);

/*
** option_p.c
*/
void		option_p(char *name, t_header *header, t_options *options);

/*
** read_data.c
*/
typedef struct	s_file
{
  int		size;
  char		*data;
}		t_file;
t_file		read_data(char *file);

/*
** write.c
*/
void		write_archive(char *file, t_list *archive, t_options *options);
void		write_start(char *file, t_options *options);
void		write_verbose(char *file, t_options *options);

/*
** write_gzip.c
*/
void		write_gzip(char *file, t_list *archive, t_options *options);

/*
** bufferize.c
*/
char		*create_buffer(t_list *archive, int *buffer_size);

#endif
