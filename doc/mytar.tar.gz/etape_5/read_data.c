/*
** read_data.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sat Nov 21 12:01:18 2009 martin tapia
** Last update Sat Nov 21 12:11:46 2009 martin tapia
*/

#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "mytar.h"

void		read_data_error(char *file)
{
  my_putstr("Cannot read ");
  my_putstr(file);
  my_putstr(".\n");
  exit(EXIT_FAILURE);
}

t_file		read_data(char *path)
{
  int		fd;
  t_file	file;

  file.size = 0;
  file.data = NULL;
  fd = open(path, O_RDONLY);
  if (fd != -1)
    {
      file.size = lseek(fd, 0, SEEK_END);
      if (file.size <= 0)
        return (file);
      lseek(fd, 0, SEEK_SET);
      file.data = malloc(file.size * sizeof(*(file.data)));
      if (read(fd, file.data, file.size) != file.size)
        free(file.data);
      close(fd);
    }
  else
    read_data_error(path);
  return (file);
}
