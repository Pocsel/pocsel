/*
** header.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sat Nov 21 10:38:05 2009 martin tapia
** Last update Sat Nov 21 15:21:03 2009 martin tapia
*/

#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>
#include "mytar.h"

void		write_header_name(char *tab, char *file)
{
  int		len;
  int		i;

  len = my_strlen(file);
  if (len > 99)
    die_with_error("File name too long.\n");
  i = 0;
  while (i < len)
    {
      tab[i] = file[i];
      i = i + 1;
    }
  while (i < 100)
    {
      tab[i] = '\0';
      i = i + 1;
    }
}

void		write_header_flag(char *tab, mode_t st_mode)
{
  if ((st_mode & S_IFMT) == S_IFLNK)
    tab[0] = '2';
  else
    tab[0] = '0';
}

void		write_header_link(char *tab, struct stat s, char *file)
{
  int		len;
  int		i;

  len = 0;
  if ((s.st_mode & S_IFMT) == S_IFLNK)
    {
      len = readlink(file, tab, 99);
      if (len < 0)
	die_with_error("Cannot read link.\n");
    }
  i = len;
  while (i < 100)
    {
      tab[i] = '\0';
      i = i + 1;
    }
}

void		write_header_padding(char *tab)
{
  int		i;

  i = 0;
  while (i < 255)
    {
      tab[i] = '\0';
      i = i + 1;
    }
}

void		write_header_checksum(t_header *header)
{
  int		checksum;
  unsigned int	i;

  i = 0;
  while (i < 8)
    {
      header->checksum[i] = ' ';
      i = i + 1;
    }
  i = 0;
  checksum = 0;
  while (i < sizeof(*header))
    {
      checksum = checksum + *(header->name + i);
      i = i + 1;
    }
  to_octal(header->checksum, 8, checksum, 1);
  header->checksum[6] = '\0';
  header->checksum[7] = ' ';
}
