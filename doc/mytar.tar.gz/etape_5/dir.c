/*
** dir.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar/etape_2/my_archive
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sat Nov 21 19:18:33 2009 martin tapia
** Last update Sun Nov 22 11:10:15 2009 martin tapia
*/

#include <sys/param.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdlib.h>
#include "mytar.h"

void		dir_add_entry(char *path, t_list **archive, t_options *o)
{
  char		file_name[MAXPATHLEN];
  t_header	header;

  write_verbose(path, o);
  my_strcpy(file_name, path);
  header = fill_header(path);
  to_octal(header.size, 12, 0, 0);
  header.flag[0] = '5';
  write_header_checksum(&header);
  list_add(archive, header, NULL, 0);
}

void		dir_add(DIR *d, t_list **archive, char *path, t_options *o)
{
  struct dirent	*dp;
  DIR		*new_d;
  char		new_path[MAXPATHLEN];

  dir_add_entry(path, archive, o);
  while ((dp = readdir(d)) != NULL)
    {
      my_strcpy(new_path, path);
      my_strcat(new_path, "/");
      my_strcat(new_path, dp->d_name);
      if (my_strcmp(dp->d_name, ".") && my_strcmp(dp->d_name, ".."))
	{
	  if (file_is_link(new_path))
	    file_add(new_path, archive, o);
	  else if ((new_d = opendir(new_path)) == NULL)
	    file_add(new_path, archive, o);
	  else
	    dir_add(new_d, archive, new_path, o);
	}
    }
  closedir(d);
}
