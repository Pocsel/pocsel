/*
** fill_archive.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar/etape_3
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sat Nov 21 21:28:42 2009 martin tapia
** Last update Sun Nov 22 11:10:30 2009 martin tapia
*/

#include <sys/param.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "mytar.h"

t_header	fill_header(char *file)
{
  t_header	header;
  struct stat	s;

  if (lstat(file, &s) == -1)
    {
      my_putstr("Cannot add ");
      my_putstr(file);
      my_putstr(".\n");
      exit(EXIT_FAILURE);
    }
  write_header_name(header.name, file);
  to_octal(header.mode, 8, s.st_mode & ALLPERMS, 1);
  to_octal(header.owner, 8, s.st_uid, 1);
  to_octal(header.group, 8, s.st_gid, 1);
  to_octal(header.size, 12,
	   ((s.st_mode & S_IFMT) == S_IFLNK) ? 0 : s.st_size, 0);
  to_octal(header.time, 12, s.st_mtime, 0);
  write_header_flag(header.flag, s.st_mode);
  write_header_link(header.link, s, file);
  write_header_padding(header.padding);
  return (header);
}

void		file_add(char *file, t_list **archive, t_options *options)
{
  t_header	header;
  t_file	data;

  write_verbose(file, options);
  header = fill_header(file);
  write_header_checksum(&header);
  if (header.flag[0] == '0')
    {
      data = read_data(file);
      list_add(archive, header, data.data, data.size);
    }
  else
    list_add(archive, header, NULL, 0);  
}

void		fill_archive(int argc, char **argv, t_list **archive, t_options *o)
{
  int		i;
  DIR		*d;

  write_start(argv[2], o);
  i = 3;
  while (i < argc)
    {
      if ((d = opendir(argv[i])) == NULL)
	file_add(argv[i], archive, o);
      else
	dir_add(d, archive, argv[i], o);
      i = i + 1;
    }
}
