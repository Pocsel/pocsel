/*
** main.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Fri Nov 20 20:41:16 2009 martin tapia
** Last update Sun Nov 22 13:43:50 2009 martin tapia
*/

#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include "mytar.h"

void		unarchive(int fd, t_options *options)
{
  t_header	header;
  int		done;
  int		nb_read;

  nb_read = 0;
  done = 0;
  while (!done &&
         read(fd, &header, sizeof(header)) == sizeof(header))
    {
      nb_read = nb_read + 1;
      if (header_is_empty(&header))
        done = 1;
      else
        {
          if (verify_checksum(&header))
            die_with_error("Checksum error.\n");
          unarchive_write(fd, &header, options);
        }
    }
  if ((nb_read > 0) && options->verbose)
    my_putstr("Done.\n");
  else if (!(nb_read > 0))
    my_putstr("Bad format.\n");
}

void		main_tar(int argc, char **argv, t_options *options)
{
  t_list	*archive;

  archive = NULL;
  fill_archive(argc, argv, &archive, options);
  if (options->gzip)
    write_gzip(argv[2], archive, options);
  else
    write_archive(argv[2], archive, options);
  list_free(&archive);
}

void		main_detar(char *path, t_options *options)
{
  int		fd;

  fd = open(path, O_RDONLY);
  if (fd == - 1)
    die_with_error("Cannot read archive.\n");
  if (options->verbose)
    {
      my_putstr("Reading archive ");
      my_putstr(path);
      my_putstr(".\n");
    }
  unarchive(fd, options);
  close(fd);
}

int		main(int argc, char **argv)
{
  t_options	options;

  options_default(&options);
  if (argc >= 3)
    {
      options_parse(&options, argv[1]);
      if ((options.extract && options.create) || (options.list && options.create))
	die_with_error("Invalid options.\n");
      if (options.extract || options.list)
	main_detar(argv[2], &options);
      else if (options.create && argc >= 4)
	main_tar(argc, argv, &options);
      else
	die_with_error("Invalid options.\n");
    }
  else
    my_putstr("Usage: ./my_tar xcvftp file [...]\n");
  return (EXIT_SUCCESS);
}
