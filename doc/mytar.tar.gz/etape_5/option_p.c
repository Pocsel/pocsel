/*
** option_p.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar/etape_3
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sun Nov 22 11:26:29 2009 martin tapia
** Last update Sun Nov 22 13:28:29 2009 martin tapia
*/

#include <stdlib.h>
#include <sys/stat.h>
#include <sys/time.h>
#include "mytar.h"

int			get_header_time(t_header *header)
{
  char			*time_str;
  int			time;

  time_str = malloc_header_field(header->time, 11);
  time = my_getnbr_base(time_str, OCTAL);
  free(time_str);
  return (time);
}

int			get_header_mode(t_header *header)
{
  char			*mode_str;
  int			mode;

  mode_str = malloc_header_field(header->mode, 6);
  mode = my_getnbr_base(mode_str, OCTAL);
  free(mode_str);
  return (mode);
}

void			option_p(char *name, t_header *header, t_options *options)
{
  struct timeval	times[2];

  if (options->perm)
    {
      times[0].tv_sec = get_header_time(header);
      times[1].tv_sec = get_header_time(header);
      times[0].tv_usec = 0;
      times[1].tv_usec = 0;
      if (utimes(name, times) == -1)
	my_putstr("Warning: Cannot change file modification time.\n");
      if (chmod(name, get_header_mode(header)) == -1)
	my_putstr("Warning: Cannot change file permissions.\n");
    }
}
