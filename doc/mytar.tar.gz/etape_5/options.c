/*
** options.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar/etape_3
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sat Nov 21 21:51:22 2009 martin tapia
** Last update Sun Nov 22 13:42:08 2009 martin tapia
*/

#include <stdlib.h>
#include "mytar.h"

void		options_default(t_options *options)
{
  options->create = 0;
  options->extract = 0;
  options->file = 0;
  options->list = 0;
  options->perm = 0;
  options->verbose = 0;
  options->gzip = 0;
}

int		options_set(t_options *options, char o)
{
  if (o == 'c')
    options->create = 1;
  else if (o == 'x')
    options->extract = 1;
  else if (o == 'f')
    options->file = 1;
  else if (o == 't')
    options->list = 1;
  else if (o == 'p')
    options->perm = 1;
  else if (o == 'v')
    options->verbose = 1;
  else if (o == 'z')
    options->gzip = 1;
  else if (o == '-')
    return (1);
  else
    return (0);
  return (1);
}

void		options_parse(t_options *options, char *str)
{
  int		i;

  i = 0;
  while (str[i] != '\0')
    {
      if (options_set(options, str[i]) == 0)
	die_with_error("Incorrect options.\n");
      i = i + 1;
    }
}
