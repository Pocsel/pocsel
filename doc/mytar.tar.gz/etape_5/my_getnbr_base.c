/*
** my_getnbr_base.c for my_getnbr_base in /u/all/tapia_a/cu/rendu/piscine/Jour_06_tmp
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Mon Oct 12 17:08:11 2009 martin tapia
** Last update Sat Nov 21 21:39:59 2009 martin tapia
*/

int	my_getnbr_base_value(char c, char *base)
{
  int	i;

  i = 0;
  while (base[i] != '\0')
    {
      if (base[i] == c)
	return (i);
      i = i + 1;
    }
  return (0);
}

int	my_getnbr_base(char *str, char *base)
{
  int	b;
  int	sign;
  int	nbr;

  b = 0;
  while (base[b] != '\0')
    b = b + 1;
  if (b < 2)
    return (0);
  sign = 1;
  nbr = 0;
  while (*str != '\0')
    {
      if (*str == '-')
	sign = sign * -1;
      else
	nbr = nbr * b + my_getnbr_base_value(*str, base);
      str = str + 1;
    }
  return (nbr * sign);
}
