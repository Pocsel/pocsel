/*
** utils.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sat Nov 21 10:28:11 2009 martin tapia
** Last update Sat Nov 21 21:38:07 2009 martin tapia
*/

#include <stdlib.h>
#include "mytar.h"

int		header_is_empty(t_header *header)
{
  unsigned int	i;

  i = 0;
  while (i < sizeof(*header))
    {
      if (*(header->name + i) != '\0')
        return (0);
      i = i + 1;
    }
  return (1);
}

char		*malloc_header_field(char *tab, int size)
{
  char		*ret;
  int		i;

  ret = malloc(sizeof(*ret) * (size + 1));
  if (ret == NULL)
    die_with_error("Could not allocate memory.\n");
  i = 0;
  while (i < size)
    {
      ret[i] = tab[i];
      i = i + 1;
    }
  ret[i] = '\0';
  return (ret);
}

int		file_is_link(char *path)
{
  struct stat	s;

  if (lstat(path, &s) == -1)
    die_with_error("Cannot lstat.\n");
  if ((s.st_mode & S_IFMT) == S_IFLNK)
    return (1);
  return (0);
}

char		*my_strcat(char *str1, char *str2)
{
  char	*str;

  str = str1;
  while (*str1 != '\0')
    str1 = str1 + 1;
  while (*str2 != '\0')
    {
      *str1 = *str2;
      str1 = str1 + 1;
      str2 = str2 + 1;
    }
  *str1 = '\0';
  return (str);
}

void		die_with_error(char *str)
{
  my_putstr(str);
  exit(EXIT_FAILURE);
}
