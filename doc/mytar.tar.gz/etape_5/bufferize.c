/*
** bufferize.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar/etape_5
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sun Nov 22 14:49:09 2009 martin tapia
** Last update Sun Nov 22 15:15:33 2009 martin tapia
*/

#include <stdlib.h>
#include <unistd.h>
#include "mytar.h"

int		buffer_len(t_list *archive)
{
  int		buffer_size;

  buffer_size = 0;
  while (archive != NULL)
    {
      buffer_size = buffer_size + RECORDSIZE + archive->size;
      if (!(buffer_size % RECORDSIZE == 0))
	buffer_size = buffer_size + RECORDSIZE - (buffer_size % RECORDSIZE);
      archive = archive->next;
    }
  buffer_size = buffer_size + RECORDSIZE * 2;
  return (buffer_size);
}

void		empty_buffer(char *buffer, int size)
{
  int		i;

  i = 0;
  while (i < size)
    {
      buffer[i] = '\0';
      i = i + 1;
    }
}

void		buffer_fill_header(t_header *header, int *pos, char *buffer)
{
  int		i;

  i = 0;
  while (i < RECORDSIZE)
    {
      buffer[*pos] = *(header->name + i);
      *pos = *pos + 1;
      i = i + 1;
    }
}

void		buffer_fill_data(char *data, int size, int *pos, char *buffer)
{
  int		i;

  i = 0;
  while (i < size)
    {
      buffer[*pos] = data[i];
      *pos = *pos + 1;
      i = i + 1;
    }
  if (!(size % RECORDSIZE == 0))
    {
      size = RECORDSIZE - (size % RECORDSIZE);
      i = 0;
      while (i < size)
	{
	  buffer[*pos] = '\0';
	  *pos = *pos + 1;
	  i = i + 1;
	}
    }
}

char		*create_buffer(t_list *archive, int *buffer_size)
{
  char		*buffer;
  int		pos;
  char		*junk;

  pos = 0;
  *buffer_size = buffer_len(archive);
  if ((buffer = malloc(sizeof(*buffer) * (*buffer_size))) == NULL)
    die_with_error("Could not allocate memory.\n");
  empty_buffer(buffer, *buffer_size);
  while (archive != NULL)
    {
      buffer_fill_header(&(archive->header), &pos, buffer);
      buffer_fill_data(archive->data, archive->size, &pos, buffer);
      archive = archive->next;
    }
  if ((junk = malloc(sizeof(*junk) * RECORDSIZE)) == NULL)
    die_with_error("Could not allocate memory.\n");
  empty_buffer(junk, RECORDSIZE);
  buffer_fill_data(junk, RECORDSIZE, &pos, buffer);
  buffer_fill_data(junk, RECORDSIZE, &pos, buffer);
  free(junk);
  return (buffer);
}
