/*
** revstr.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Fri Nov 20 22:36:09 2009 martin tapia
** Last update Fri Nov 20 22:37:56 2009 martin tapia
*/

int	my_revstr_strlen(char *str)
{
  int	l;

  l = 0;
  while (*str != '\0')
    {
      l = l + 1;
      str = str + 1;
    }
  return (l);
}

int	my_revstr_swap(char *a, char *b)
{
  char	c;

  c = *a;
  *a = *b;
  *b = c;
  return (0);
}

char	*my_revstr(char *str)
{
  int	len;
  int	i;

  if (!str)
    {
      return (0);
    }
  len = my_revstr_strlen(str);
  i = 0;
  while (i < len / 2)
    {
      my_revstr_swap(&str[i], &str[len - i - 1]);
      i = i + 1;
    }
  return (str);
}
