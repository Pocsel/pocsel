/*
** octal.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Fri Nov 20 22:17:21 2009 martin tapia
** Last update Sat Nov 21 11:45:30 2009 martin tapia
*/

#include <stdlib.h>
#include "mytar.h"

void		to_octal(char *tab, int size, int val, int null_finish)
{
  char		*nbr;
  int		len;
  int		i;
  int		pos;

  nbr = convert_base(val, DECIMAL, OCTAL);
  len = my_strlen(nbr);
  if (len > size - (null_finish ? 2 : 1))
    die_with_error("Error: Cannot create header.\n");
  i = 0;
  while (i < size - len - (null_finish ? 2 : 1))
    {
      tab[i] = '0';
      i = i + 1;
    }
  pos = i;
  i = 0;
  while (i < len)
    {
      tab[pos] = nbr[i];
      pos = pos + 1;
      i = i + 1;
    }
  tab[pos] = ' ';
  if (null_finish)
    tab[pos + 1] = '\0';
  free(nbr);
}
