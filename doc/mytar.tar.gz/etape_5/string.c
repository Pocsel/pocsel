/*
** my_putstr.c for my_putstr in /u/all/tapia_a/cu/rendu/piscine/Jour_04
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Thu Oct  8 10:09:51 2009 martin tapia
** Last update Sat Nov 21 18:22:53 2009 martin tapia
*/

#include <unistd.h>

int	my_strcmp(char *s1, char *s2)
{
  while ((*s1 != '\0') && (*s2 != '\0'))
    {
      if (*s1 > *s2)
	return (1);
      else if (*s1 < *s2)
	return (-1);
      s1 = s1 + 1;
      s2 = s2 + 1;
    }
  if (*s1 > *s2)
    return (1);
  else if (*s1 < *s2)
    return (-1);
  return (0);
}

char	*my_strcpy(char *dest, char *src)
{
  int	i;

  i = 0;
  while (src[i] != '\0')
    {
      dest[i] = src[i];
      i = i + 1;
    }
  dest[i] = '\0';
  return (dest);
}

int	my_strlen(char *str)
{
  int	l;

  if (!str)
    {
      return (-1);
    }
  l = 0;
  while (*str != '\0')
    {
      l = l + 1;
      str = str + 1;
    }
  return (l);
}

void	my_putchar(char c)
{
  write(1, &c, 1);
}

int	my_putstr(char *str)
{
  if (!str)
    {
      return (-1);
    }
  while (*str != '\0')
    {
      my_putchar(*str);
      str = str + 1;
    }
  return (0);
}
