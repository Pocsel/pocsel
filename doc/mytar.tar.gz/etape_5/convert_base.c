/*
** convert_base.c for convert_base in /u/all/tapia_a/cu/rendu/piscine/Jour_08
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Wed Oct 14 11:07:07 2009 martin tapia
** Last update Fri Nov 20 22:38:49 2009 martin tapia
*/

#include <stdlib.h>
#include "mytar.h"

void	convert_base_tab_rec(int nbr, int base, char *out, char *tab)
{
  int	unit;

  if (nbr > 0)
    {
      unit = nbr % base;
      convert_base_tab_rec(nbr / base, base, out, tab + 1);
      *tab = out[unit];
    }
}

void	convert_base_tab(int nbr, char *base, char *tab)
{
  int	b;

  b = 0;
  while (base[b] != '\0')
    b = b + 1;
  if (b < 2)
    return ;
  if (nbr < 0)
    {
      nbr = nbr * -1;
    }
  if (nbr == 0)
    *tab = base[0];
  else
    convert_base_tab_rec(nbr, b, base, tab);
}

void	convert_base_minus(char *ret)
{
  int	i;

  i = 0;
  while (ret[i] != '\0')
    {
      i = i + 1;
    }
  i = i + 1;
  while (i > 0)
    {
      ret[i] = ret[i - 1];
      i = i - 1;
    }
  ret[0] = '-';
}

char	*convert_base(int i, char *base_from, char *base_to)
{
  int	j;
  char	c[34];
  char	*ret;

  if (!base_from || !base_to)
    return (0);
  j = 0;
  while (j < 34)
    {
      c[j] = '\0';
      j = j + 1;
    }
  convert_base_tab(i, base_to, c);
  if (i < 0)
    ret = malloc((my_strlen(c) + 2) * sizeof(*ret));
  else
    ret = malloc((my_strlen(c) + 1) * sizeof(*ret));
  my_revstr(my_strcpy(ret, c));
  if (i < 0)
    convert_base_minus(ret);
  if (!ret)
    return (0);
  return (ret);
}
