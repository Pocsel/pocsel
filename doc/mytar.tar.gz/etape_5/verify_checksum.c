/*
** verify_checksum.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar/etape_1/my_unarchive
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sat Nov 21 15:09:57 2009 martin tapia
** Last update Sat Nov 21 21:36:40 2009 martin tapia
*/

#include <stdlib.h>
#include "mytar.h"

int		get_signed_checksum(t_header *header)
{
  int		checksum;
  unsigned int	i;

  i = 0;
  checksum = 0;
  while (i < sizeof(*header))
    {
      checksum = checksum + *(header->name + i);
      i = i + 1;
    }
  return (checksum);
}

int		get_unsigned_checksum(t_header *header)
{
  int		checksum;
  unsigned int	i;

  i = 0;
  checksum = 0;
  while (i < sizeof(*header))
    {
      checksum = checksum + (unsigned char)(*(header->name + i));
      i = i + 1;
    }
  return (checksum);
}

int		get_checksum(t_header *header)
{
  char		*checksum_str;
  int		checksum;

  checksum_str = malloc_header_field(header->checksum, 6);
  checksum = my_getnbr_base(checksum_str, OCTAL);
  free(checksum_str);
  return (checksum);
}

int		verify_checksum(t_header *header)
{
  int		checksum;
  unsigned int	i;

  checksum = get_checksum(header);
  i = 0;
  while (i < 8)
    {
      header->checksum[i] = ' ';
      i = i + 1;
    }
  if (checksum == get_unsigned_checksum(header) ||
      checksum == get_signed_checksum(header))
    return (0);
  return (1);
}
