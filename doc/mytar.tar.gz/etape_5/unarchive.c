/*
** unarchive.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar/etape_1/my_unarchive
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sat Nov 21 16:15:38 2009 martin tapia
** Last update Sun Nov 22 12:51:57 2009 martin tapia
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include "mytar.h"

int		get_header_filesize(t_header *header)
{
  char		*size_str;
  int		size;

  size_str = malloc_header_field(header->size, 11);
  size = my_getnbr_base(size_str, OCTAL);
  free(size_str);
  return (size);
}

void		unarchive_write_file(int fd, int size, char *name)
{
  int		new_fd;
  char		*data;

  new_fd = open(name, O_RDWR | O_CREAT | O_TRUNC, 0644);
  if (new_fd == -1)
    die_with_error("Cannot create new file.\n");
  data = malloc(sizeof(*data) * size);
  if (data == NULL)
    die_with_error("Cannot allocate memory.\n");
  if (read(fd, data, size) != size)
    die_with_error("Invalid file size.\n");
  if (write(new_fd, data, size) != size)
    die_with_error("Cannot write to new file.\n");
  free(data);
  close(new_fd);
}

void		unarchive_put_file(char *path, t_options *options)
{
  if (options->verbose)
    {
      my_putstr("Creating ");
      my_putstr(path);
      my_putstr(".\n");
    }
}

void		unarchive_dir(char *path)
{
  if (mkdir(path, 0755) == -1)
    die_with_error("Cannot create directory.\n");
}

void		unarchive_write(int fd, t_header *header, t_options *options)
{
  char		dump[RECORDSIZE];
  char		*name;
  char		*link;
  int		size;

  name = malloc_header_field(header->name, 100);
  if (listing(options, name, header, fd))
    return ;
  link = malloc_header_field(header->link, 100);
  unarchive_put_file(name, options);
  if (header->flag[0] == '5')
    unarchive_dir(name);
  else if (link[0] == '\0')
    {
      size = get_header_filesize(header);
      unarchive_write_file(fd, size, name);
      if (size != 0 && read(fd, dump, RECORDSIZE - size % RECORDSIZE)
	  != RECORDSIZE - size % RECORDSIZE)
	die_with_error("Invalid file size.\n");
    }
  else if (symlink(link, name) == -1)
    die_with_error("Cannot create symbolic link.\n");
  option_p(name, header, options);
  free(link);
  free(name);
}
