/*
** option_t.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar/etape_3
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sun Nov 22 10:37:11 2009 martin tapia
** Last update Sun Nov 22 10:59:27 2009 martin tapia
*/

#include <stdlib.h>
#include <unistd.h>
#include "mytar.h"

int		listing(t_options *options, char *path, t_header *header, int fd)
{
  int		size;
  int		bytes_read;
  char		dump[RECORDSIZE];

  if (options->list)
    {
      my_putstr("-> ");
      my_putstr(path);
      my_putstr("\n");
      free(path);
      size = get_header_filesize(header);
      if (size > 0)
	{
	  bytes_read = 0;
	  while (bytes_read < size)
	    {
	      read(fd, dump, RECORDSIZE);
	      bytes_read = bytes_read + RECORDSIZE;
	    }
	}
      return (1);
    }
  return (0);
}
