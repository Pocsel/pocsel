/*
** write.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sat Nov 21 13:47:47 2009 martin tapia
** Last update Sun Nov 22 14:25:49 2009 martin tapia
*/

#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "mytar.h"

void		write_end_of_file(int fd, t_options *options)
{
  char		record[RECORDSIZE];
  int		i;

  i = 0;
  while (i < RECORDSIZE)
    {
      record[i] = '\0';
      i = i + 1;
    }
  write(fd, record, RECORDSIZE);
  write(fd, record, RECORDSIZE);
  if (options->verbose)
    my_putstr("Done.\n");
  close(fd);
}

void		write_start(char *file, t_options *options)
{
  if (options->verbose)
    {
      my_putstr("Creating archive ");
      my_putstr(file);
      my_putstr(".\n");
    }
}

void		write_verbose(char *file, t_options *options)
{
  if (options->verbose)
    {
      my_putstr("Adding ");
      my_putstr(file);
      my_putstr(".\n");      
    }
}

void		write_archive(char *file, t_list *archive, t_options *options)
{
  int		fd;
  char		record[RECORDSIZE];
  int		i;
  
  i = 0;
  while (i < RECORDSIZE)
    {
      record[i] = '\0';
      i = i + 1;
    }
  if ((fd = open(file, O_RDWR | O_CREAT | O_TRUNC, 0644)) == -1)
    die_with_error("Cannot write archive.\n");
  while (archive != NULL)
    {
      write(fd, &archive->header, sizeof(t_header));
      write(fd, archive->data, archive->size);
      if (archive->size != 0)
	write(fd, record, RECORDSIZE - archive->size % RECORDSIZE);
      archive = archive->next;
    }
  write_end_of_file(fd, options);
}
