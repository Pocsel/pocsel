/*
** write_gzip.c for mytar in /u/all/tapia_a/cu/rendu/rush/mytar/etape_5
** 
** Made by martin tapia
** Login   <tapia_a@epitech.net>
** 
** Started on  Sun Nov 22 13:44:03 2009 martin tapia
** Last update Sun Nov 22 17:13:38 2009 martin tapia
*/

#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <zlib.h>
#include "mytar.h"

/*
** deflate:
** http://www.zlib.net/zlib_faq.html#faq36
** 
** "That is intentional for performance reasons,
** and the output of deflate is not affected."
*/
void		write_gzip_file(z_stream *strm, char *file, char *buffer, int size)
{
  int		fd;
  int		gzipped_bytes;
  char		out[GZIP_CHUNK];

  if ((fd = open(file, O_RDWR | O_CREAT | O_TRUNC, 0644)) == -1)
    die_with_error("Cannot write archive.\n");
  strm->avail_in = size;
  strm->next_in = buffer;
  gzipped_bytes = 1;
  while (gzipped_bytes > 0)
    {
      strm->avail_out = GZIP_CHUNK;
      strm->next_out = out;
      if (deflate(strm, Z_FINISH) == Z_STREAM_ERROR)
	die_with_error("Error during deflate.\n");
      gzipped_bytes = GZIP_CHUNK - strm->avail_out;
      if (write(fd, out, gzipped_bytes) == -1)
	die_with_error("Cannot write compressed file.\n");
    }
  close(fd);
}

void		write_gzip(char *file, t_list *archive, t_options *options)
{
  z_stream	strm;
  char		*buffer;
  int		buffer_size;

  strm.zalloc = Z_NULL;
  strm.zfree = Z_NULL;
  strm.opaque = Z_NULL;
  if (deflateInit2(&strm, Z_DEFAULT_COMPRESSION,
		   Z_DEFLATED, 15 + 16, 8, Z_DEFAULT_STRATEGY) != Z_OK)
    die_with_error("Cannot initialize zlib.\n");
  buffer = create_buffer(archive, &buffer_size);
  write_gzip_file(&strm, file, buffer, buffer_size);
  free(buffer);
  deflateEnd(&strm);
  my_putstr("Done.\n");
}
